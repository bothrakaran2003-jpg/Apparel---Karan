import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random

def generate_dataset(n=1000, seed=42):
    np.random.seed(seed)
    random.seed(seed)

    # ── Consumer Profile ──────────────────────────────────────────────────────
    age_groups   = np.random.choice(["18-25","26-35","36-45","46-55","56+"],
                                     n, p=[0.15,0.30,0.28,0.18,0.09])
    income_level = np.random.choice(["<5K AED","5-10K AED","10-20K AED","20-40K AED","40K+ AED"],
                                     n, p=[0.10,0.22,0.30,0.25,0.13])
    nationality  = np.random.choice(["Indian","Pakistani","Emirati","Bangladeshi","Sri Lankan","Other Arab","Western"],
                                     n, p=[0.35,0.18,0.12,0.10,0.07,0.10,0.08])
    style_pref   = np.random.choice(["Traditional","Fusion","Contemporary","Festive","Casual Ethnic"],
                                     n, p=[0.25,0.22,0.18,0.20,0.15])

    # ── Product Mix ───────────────────────────────────────────────────────────
    size_range   = np.random.choice(["S","M","L","XL","XXL","Custom"],
                                     n, p=[0.08,0.22,0.30,0.25,0.10,0.05])
    product_type = np.random.choice(["Kurta","Sherwani","Pathani Suit","Achkan","Dhoti Kurta","Fusion Jacket","Indo-Western"],
                                     n, p=[0.28,0.20,0.15,0.10,0.08,0.12,0.07])
    is_festive   = np.random.choice(["Festive","Regular"], n, p=[0.45,0.55])
    is_fusion    = np.where(
        np.isin(product_type, ["Fusion Jacket","Indo-Western"]), "Yes", "No")

    # ── Location Preference ───────────────────────────────────────────────────
    location     = np.random.choice(["Mall","High Street","Nearby Retail","Online","Pop-up/Event"],
                                     n, p=[0.35,0.25,0.20,0.12,0.08])

    # ── Pricing Strategy ─────────────────────────────────────────────────────
    price_tier   = np.random.choice(["Affordable","Mid-Premium","Premium"],
                                     n, p=[0.30,0.45,0.25])
    avg_spend_map = {"Affordable":220,"Mid-Premium":580,"Premium":1350}
    avg_spend     = np.array([avg_spend_map[t] for t in price_tier]) + np.random.normal(0, 40, n)
    avg_spend     = np.clip(avg_spend, 80, 3000).astype(int)

    # ── Inventory Turnover ────────────────────────────────────────────────────
    movement      = np.random.choice(["Fast Moving","Moderate","Slow Moving"], n, p=[0.40,0.35,0.25])
    stock_age_map = {"Fast Moving": (5,25), "Moderate": (25,60), "Slow Moving": (60,180)}
    stock_age_days = np.array([int(np.random.uniform(*stock_age_map[m])) for m in movement])
    reorder_freq   = np.random.choice(["Weekly","Bi-Weekly","Monthly","Quarterly"], n, p=[0.20,0.35,0.30,0.15])

    # ── Marketing Effectiveness ───────────────────────────────────────────────
    social_reach    = np.random.randint(200, 50000, n)
    instore_traffic = np.random.randint(10, 500, n)
    conversion_rate = np.clip(np.random.normal(0.12, 0.04, n), 0.02, 0.45)
    repeat_purchase = np.random.choice(["Yes","No"], n, p=[0.38,0.62])
    channel_source  = np.random.choice(["Instagram","WhatsApp","Walk-in","Referral","Google","TikTok","Event"],
                                        n, p=[0.28,0.18,0.20,0.14,0.10,0.07,0.03])

    # ── Derived / Contextual ──────────────────────────────────────────────────
    season = np.random.choice(
        ["Eid al-Fitr","Eid al-Adha","Diwali","Wedding Season","National Day","Off-Peak"],
        n, p=[0.18,0.15,0.14,0.20,0.08,0.25])

    satisfaction = np.clip(np.random.normal(3.8, 0.8, n), 1, 5).round(1)

    # Purchase intent (target variable for ML)
    # Higher intent driven by: festive, premium, mall, high social reach, young
    score = (
        (is_festive == "Festive").astype(int) * 2 +
        (price_tier == "Premium").astype(int) * 1 +
        (location == "Mall").astype(int) * 1 +
        (social_reach > 10000).astype(int) * 1 +
        (np.isin(age_groups, ["26-35","36-45"])).astype(int) * 1 +
        (repeat_purchase == "Yes").astype(int) * 2
    )
    purchase_intent = np.where(score >= 4, "High", np.where(score >= 2, "Medium", "Low"))

    # ── Build DataFrame ───────────────────────────────────────────────────────
    df = pd.DataFrame({
        # Consumer Profile
        "Age_Group": age_groups,
        "Income_Level": income_level,
        "Nationality": nationality,
        "Style_Preference": style_pref,
        # Product Mix
        "Size_Range": size_range,
        "Product_Type": product_type,
        "Wear_Category": is_festive,
        "Is_Fusion": is_fusion,
        # Location
        "Location_Preference": location,
        # Pricing
        "Price_Tier": price_tier,
        "Avg_Spend_AED": avg_spend,
        # Inventory
        "Stock_Movement": movement,
        "Stock_Age_Days": stock_age_days,
        "Reorder_Frequency": reorder_freq,
        # Marketing
        "Social_Media_Reach": social_reach,
        "Instore_Traffic": instore_traffic,
        "Conversion_Rate": (conversion_rate * 100).round(2),
        "Repeat_Purchase": repeat_purchase,
        "Marketing_Channel": channel_source,
        # Context
        "Season": season,
        "Satisfaction_Score": satisfaction,
        # Target
        "Purchase_Intent": purchase_intent
    })

    return df


def get_competitor_data():
    return pd.DataFrame({
        "Brand": ["Manyavar (Indian)","Junaid Jamshed","Ethnic by Outfitters",
                  "Fabindia","Naqsh by Sana Safinaz","Karachi Suits","Al Baraka",
                  "Lulu Ethnic Section","Generic Dubai Retailers"],
        "Type": ["Franchise","Pakistan Brand","Pakistan Brand","Indian Brand",
                 "Pakistan Brand","Local","Local","Hypermarket","Unorganised"],
        "Est_Market_Share_pct": [18, 14, 11, 8, 7, 6, 5, 9, 22],
        "Avg_Price_AED": [450, 320, 280, 380, 520, 250, 220, 180, 150],
        "Primary_Segment": ["Indian diaspora","South Asian","South Asian","Indian","Elite Pakistani",
                            "Pakistani diaspora","Budget","Mass","Budget"],
        "Store_Count_Dubai": [8, 5, 4, 3, 2, 6, 10, 12, 40],
        "Online_Presence": ["Strong","Moderate","Strong","Strong","Moderate","Weak","Weak","Moderate","Weak"]
    })
