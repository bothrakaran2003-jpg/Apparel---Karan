import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.data_generator import get_competitor_data

def show():
    st.markdown("""
    <div class="main-header">
        <h1>🧣 Dubai Men's Ethnic Wear — Market Intelligence</h1>
        <p>Competitive Landscape · Consumer Behaviour · Demand Seasonality · Strategic Entry</p>
    </div>
    """, unsafe_allow_html=True)

    # ── KPI Row ──────────────────────────────────────────────────────────────
    c1,c2,c3,c4,c5 = st.columns(5)
    kpis = [
        ("$1.8B","UAE Ethnic Wear Market Size"),
        ("12.4%","YoY Growth Rate (2024-25)"),
        ("3.4M+","South Asian Diaspora Dubai"),
        ("68%","Purchase During Festivals"),
        ("AED 380","Avg Transaction Value"),
    ]
    for col,(val,lbl) in zip([c1,c2,c3,c4,c5], kpis):
        col.markdown(f"""<div class="metric-card"><h3>{val}</h3><p>{lbl}</p></div>""",
                     unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Competitors ──────────────────────────────────────────────────────────
    st.markdown('<h3 class="section-header">🏢 Competitive Landscape</h3>', unsafe_allow_html=True)
    comp = get_competitor_data()

    col1, col2 = st.columns([1.2, 1])
    with col1:
        fig = px.pie(comp, names="Brand", values="Est_Market_Share_pct",
                     title="Estimated Market Share — Dubai Men's Ethnic Wear",
                     color_discrete_sequence=px.colors.sequential.Plasma_r,
                     hole=0.45)
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          font_color="white", title_font_color="#e94560")
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        fig2 = px.bar(comp.sort_values("Avg_Price_AED"), x="Avg_Price_AED", y="Brand",
                      orientation="h", title="Avg. Price Point by Brand (AED)",
                      color="Avg_Price_AED", color_continuous_scale="Reds")
        fig2.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                           font_color="white", title_font_color="#e94560",
                           yaxis=dict(tickfont=dict(size=10)))
        st.plotly_chart(fig2, use_container_width=True)

    st.dataframe(comp, use_container_width=True, hide_index=True)

    # ── Demand Seasonality ───────────────────────────────────────────────────
    st.markdown('<h3 class="section-header">📅 Demand Seasonality Calendar</h3>', unsafe_allow_html=True)
    months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    demand_idx = [55, 60, 65, 95, 60, 55, 85, 50, 70, 90, 80, 75]
    events = ["","","","Eid al-Fitr↑","","","Eid al-Adha↑","","","Diwali↑","Wedding↑","National Day↑"]
    fig3 = go.Figure()
    fig3.add_trace(go.Scatter(x=months, y=demand_idx, mode="lines+markers+text",
                              text=events, textposition="top center",
                              line=dict(color="#e94560", width=3),
                              marker=dict(size=10, color=demand_idx,
                                          colorscale="Reds", showscale=True)))
    fig3.update_layout(title="Monthly Demand Index — Men's Ethnic Wear Dubai",
                       paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                       font_color="white", title_font_color="#e94560",
                       xaxis=dict(gridcolor="#222"), yaxis=dict(gridcolor="#222", title="Demand Index"),
                       height=380)
    st.plotly_chart(fig3, use_container_width=True)

    # ── Consumer Behaviour ───────────────────────────────────────────────────
    st.markdown('<h3 class="section-header">👥 Consumer Behaviour Insights</h3>', unsafe_allow_html=True)
    insights = {
        "🕌 Festival-Driven Purchases": "68% of annual revenue concentrated in Eid, Diwali & Wedding Season (Oct–Mar). Consumers plan 2–4 weeks ahead.",
        "👨‍👨‍👦 Community & Word-of-Mouth": "South Asian diaspora (Indian 35%, Pakistani 18%, Bangladeshi 10%) rely heavily on community recommendations and WhatsApp groups.",
        "📱 Digital Discovery": "Instagram & TikTok drive 35%+ of brand discovery. Video try-on content converts 2.3× better than static posts.",
        "🛍️ Mall-First Experience": "35% prefer Mall retail for trust & ambience. Customisation/alteration services are a key retention driver.",
        "💳 Spend Willingness": "Mid-premium segment (AED 400–800) shows fastest growth at 18% YoY. Premium ($800+) is niche but high-margin.",
        "🔁 Low Loyalty": "Repeat purchase rate ~38%. Quality consistency and after-sale service are top gap areas vs Indian brands.",
    }
    cols = st.columns(3)
    for i,(title,desc) in enumerate(insights.items()):
        with cols[i % 3]:
            st.markdown(f"""
            <div style='background:#16213e;border:1px solid #e94560;border-radius:8px;padding:1rem;margin:0.4rem 0;min-height:120px'>
                <strong style='color:#e94560'>{title}</strong><br>
                <span style='color:#ccc;font-size:0.85rem'>{desc}</span>
            </div>""", unsafe_allow_html=True)

    # ── Strategic Gap ────────────────────────────────────────────────────────
    st.markdown('<h3 class="section-header">🎯 Market Gap & Entry Opportunity</h3>', unsafe_allow_html=True)
    gap_data = pd.DataFrame({
        "Opportunity": ["Fusion Ethnic (Indo-Western)","Custom/Bespoke Tailoring",
                        "Omnichannel (Mall + Online)","Budget-to-Mid Premium Bridge",
                        "Non-Indian South Asian Focus","Sustainable/Handloom Ethnic"],
        "Gap Score (1-10)": [8.5, 7.8, 9.0, 7.2, 8.0, 6.5],
        "Market Readiness": [8, 7, 9, 7, 8, 6],
        "Competition Intensity": [4, 3, 5, 6, 3, 2]
    })
    fig4 = px.scatter(gap_data, x="Competition Intensity", y="Gap Score (1-10)",
                      size="Market Readiness", color="Opportunity",
                      title="Market Gap Opportunity Matrix",
                      size_max=40, text="Opportunity")
    fig4.update_traces(textposition="top center")
    fig4.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                       font_color="white", title_font_color="#e94560",
                       showlegend=False)
    st.plotly_chart(fig4, use_container_width=True)
