import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.data_generator import generate_dataset

@st.cache_data
def load_data():
    return generate_dataset(1000)

@st.cache_data
def feature_engineer(df):
    fe = df.copy()

    # ── Ordinal Encodings ─────────────────────────────────────────────────────
    age_map     = {"18-25":1,"26-35":2,"36-45":3,"46-55":4,"56+":5}
    income_map  = {"<5K AED":1,"5-10K AED":2,"10-20K AED":3,"20-40K AED":4,"40K+ AED":5}
    price_map   = {"Affordable":1,"Mid-Premium":2,"Premium":3}
    move_map    = {"Slow Moving":1,"Moderate":2,"Fast Moving":3}
    reorder_map = {"Quarterly":1,"Monthly":2,"Bi-Weekly":3,"Weekly":4}

    fe["Age_Num"]      = fe["Age_Group"].map(age_map)
    fe["Income_Num"]   = fe["Income_Level"].map(income_map)
    fe["Price_Num"]    = fe["Price_Tier"].map(price_map)
    fe["Movement_Num"] = fe["Stock_Movement"].map(move_map)
    fe["Reorder_Num"]  = fe["Reorder_Frequency"].map(reorder_map)

    # ── Binary Flags ──────────────────────────────────────────────────────────
    fe["Is_Festive_Flag"]  = (fe["Wear_Category"]=="Festive").astype(int)
    fe["Is_Fusion_Flag"]   = (fe["Is_Fusion"]=="Yes").astype(int)
    fe["Repeat_Flag"]      = (fe["Repeat_Purchase"]=="Yes").astype(int)
    fe["Is_Mall"]          = (fe["Location_Preference"]=="Mall").astype(int)
    fe["Is_Online"]        = (fe["Location_Preference"]=="Online").astype(int)
    fe["Is_Premium"]       = (fe["Price_Tier"]=="Premium").astype(int)
    fe["Is_Affordable"]    = (fe["Price_Tier"]=="Affordable").astype(int)

    # ── Festival Season Flag ──────────────────────────────────────────────────
    festive_seasons = ["Eid al-Fitr","Eid al-Adha","Diwali","Wedding Season","National Day"]
    fe["Is_Peak_Season"]   = fe["Season"].isin(festive_seasons).astype(int)

    # ── Nationality Group ─────────────────────────────────────────────────────
    fe["Is_South_Asian"]   = fe["Nationality"].isin(["Indian","Pakistani","Bangladeshi","Sri Lankan"]).astype(int)
    fe["Is_Emirati"]       = (fe["Nationality"]=="Emirati").astype(int)

    # ── Interaction Features ──────────────────────────────────────────────────
    fe["Festive_Premium"]  = fe["Is_Festive_Flag"] * fe["Price_Num"]
    fe["Spend_per_Reach"]  = fe["Avg_Spend_AED"] / (fe["Social_Media_Reach"] + 1)
    fe["Conversion_Traffic"]= fe["Conversion_Rate"] * fe["Instore_Traffic"]
    fe["Income_Price_Ratio"]= fe["Income_Num"] / fe["Price_Num"]

    # ── Log Transforms (skewed features) ─────────────────────────────────────
    fe["Log_Social_Reach"]  = np.log1p(fe["Social_Media_Reach"])
    fe["Log_Spend"]         = np.log1p(fe["Avg_Spend_AED"])
    fe["Log_Traffic"]       = np.log1p(fe["Instore_Traffic"])

    # ── Label Encode remaining categoricals ───────────────────────────────────
    cat_to_encode = ["Style_Preference","Product_Type","Nationality",
                     "Marketing_Channel","Size_Range","Location_Preference"]
    le = LabelEncoder()
    for c in cat_to_encode:
        fe[c+"_Enc"] = le.fit_transform(fe[c])

    # ── Target Encoding ───────────────────────────────────────────────────────
    target_map = {"Low":0,"Medium":1,"High":2}
    fe["Target"] = fe["Purchase_Intent"].map(target_map)

    feature_cols = [
        "Age_Num","Income_Num","Price_Num","Movement_Num","Reorder_Num",
        "Is_Festive_Flag","Is_Fusion_Flag","Repeat_Flag","Is_Mall","Is_Online",
        "Is_Premium","Is_Affordable","Is_Peak_Season","Is_South_Asian","Is_Emirati",
        "Festive_Premium","Spend_per_Reach","Conversion_Traffic","Income_Price_Ratio",
        "Log_Social_Reach","Log_Spend","Log_Traffic",
        "Conversion_Rate","Satisfaction_Score","Stock_Age_Days",
        "Style_Preference_Enc","Product_Type_Enc","Nationality_Enc",
        "Marketing_Channel_Enc","Size_Range_Enc","Location_Preference_Enc"
    ]

    X = fe[feature_cols]
    y = fe["Target"]
    return X, y, feature_cols

def show():
    st.markdown('<h2 class="section-header">🤖 ML Classification — Super Learning</h2>', unsafe_allow_html=True)

    df = load_data()
    X, y, feature_cols = feature_engineer(df)

    # ── Feature Engineering Summary ───────────────────────────────────────────
    with st.expander("🛠️ Feature Engineering Pipeline — Click to Expand"):
        st.markdown("""
        **31 engineered features** created from 22 raw columns across 6 transformation types:

        | Category | Features |
        |---|---|
        | **Ordinal Encoding** | Age, Income, Price Tier, Stock Movement, Reorder Frequency |
        | **Binary Flags** | Festive, Fusion, Repeat Purchase, Mall, Online, Premium, Affordable, Peak Season |
        | **Interaction Terms** | Festive×Price, Spend/Reach ratio, Conversion×Traffic, Income/Price ratio |
        | **Log Transforms** | Social Reach, Avg Spend, In-store Traffic (skewness correction) |
        | **Label Encoding** | Style, Product Type, Nationality, Channel, Size, Location |
        | **Nationality Groups** | Is_South_Asian, Is_Emirati |

        **Target:** Purchase Intent (Low=0, Medium=1, High=2) — Multi-class classification
        """)

    # ── Train-Test Split Config ───────────────────────────────────────────────
    st.markdown("### ⚙️ Model Training Configuration")
    c1,c2,c3 = st.columns(3)
    with c1:
        test_size = st.slider("Test Set Size (%)", 15, 40, 25) / 100
    with c2:
        rand_state = st.number_input("Random Seed", 1, 999, 42)
    with c3:
        st.metric("Training Samples", int(len(X)*(1-test_size)))
        st.metric("Test Samples", int(len(X)*test_size))

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=test_size, random_state=rand_state, stratify=y)
    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_tr)
    X_te_s = scaler.transform(X_te)

    st.session_state["X_tr"] = X_tr_s
    st.session_state["X_te"] = X_te_s
    st.session_state["y_tr"] = y_tr
    st.session_state["y_te"] = y_te
    st.session_state["feature_cols"] = feature_cols
    st.session_state["X_tr_raw"] = X_tr
    st.session_state["X_te_raw"] = X_te

    st.success(f"✅ Data split complete. Training: {len(X_tr)} | Test: {len(X_te)} | Features: {len(feature_cols)}")

    # ── Class Distribution ────────────────────────────────────────────────────
    import plotly.express as px
    st.markdown("### 🎯 Target Class Distribution")
    label_map = {0:"Low",1:"Medium",2:"High"}
    dist_df = pd.Series(y.map(label_map)).value_counts().reset_index()
    dist_df.columns = ["Purchase Intent","Count"]
    fig = px.pie(dist_df, names="Purchase Intent", values="Count",
                 color_discrete_sequence=["#68d391","#f6ad55","#e94560"],
                 hole=0.4, title="Purchase Intent Distribution (Target)")
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="white",
                      title_font_color="#e94560")
    st.plotly_chart(fig, use_container_width=True)

    # ── Algorithm Overview ────────────────────────────────────────────────────
    st.markdown("### 🧠 Classification Algorithms")
    algo_info = {
        "K-Nearest Neighbours (KNN)": {
            "desc": "Instance-based learner; classifies by majority vote among k nearest neighbours.",
            "strength": "Simple, effective on local patterns",
            "weakness": "Slow on large data; sensitive to irrelevant features",
            "icon": "📍"
        },
        "Decision Tree": {
            "desc": "Recursive binary splits on feature values to build an interpretable tree.",
            "strength": "Highly interpretable, handles non-linearity",
            "weakness": "Prone to overfitting without pruning",
            "icon": "🌳"
        },
        "Random Forest": {
            "desc": "Ensemble of decision trees with bagging and feature subsampling.",
            "strength": "Robust, low variance, handles high dimensions",
            "weakness": "Less interpretable than single tree",
            "icon": "🌲"
        },
        "Gradient Boosting": {
            "desc": "Sequential ensemble that corrects residual errors with new weak learners.",
            "strength": "Highest accuracy, captures complex patterns",
            "weakness": "Sensitive to hyperparameters, slower training",
            "icon": "🚀"
        }
    }
    cols = st.columns(4)
    for (name, info), col in zip(algo_info.items(), cols):
        col.markdown(f"""
        <div style='background:#16213e;border:1px solid #e94560;border-radius:8px;padding:1rem;min-height:200px'>
            <div style='font-size:2rem;text-align:center'>{info['icon']}</div>
            <strong style='color:#e94560'>{name}</strong><br>
            <small style='color:#ccc'>{info['desc']}</small><br><br>
            <small style='color:#68d391'>✅ {info['strength']}</small><br>
            <small style='color:#f6ad55'>⚠️ {info['weakness']}</small>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.info("👉 Navigate to **Model Performance** page to train all models and view results, ROC curves, and confusion matrices.")
