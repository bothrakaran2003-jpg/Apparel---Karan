import streamlit as st

def show():
    st.markdown('<h2 class="section-header">💡 Findings & Strategic Insights</h2>', unsafe_allow_html=True)

    tabs = st.tabs(["Market Findings","Consumer Insights","ML Model Insights","Strategic Recommendations","Go-to-Market"])

    with tabs[0]:
        st.markdown("### 🏢 Market Findings")
        findings = [
            ("🥇 Fragmented Market = Entry Opportunity",
             "22% of the market is held by generic/unorganised retailers. A structured brand with quality assurance can capture 5–8% market share within 2–3 years in the AED 350–800 segment."),
            ("📅 Festival Concentration Risk",
             "68% of ethnic wear revenue is concentrated in 5 peak periods (Eid×2, Diwali, Wedding Season, National Day). Operations must scale for 4–6 week burst periods."),
            ("🇮🇳 Indian Diaspora Dominance",
             "Indian community (35% of South Asian population) is the primary consumer segment. Kurtas and Sherwanis dominate demand. Bangladeshi and Pakistani segments are underserved."),
            ("📱 Digital-First Discovery",
             "Instagram and TikTok now drive 35%+ of brand discovery in Dubai's ethnic wear category. Brands without strong short-video content are losing reach."),
            ("🏷️ Mid-Premium Gap",
             "The AED 400–800 Mid-Premium segment is the fastest-growing (18% YoY) and has the lowest brand competition per price point — this is the sweet spot for a new entrant."),
            ("🏭 Manufacturing Advantage",
             "Own manufacturing in Dubai enables 20–35% cost advantage vs import-only retailers and enables custom/bespoke orders within 5–7 days — a key differentiator."),
        ]
        for title, body in findings:
            st.markdown(f"""
            <div style='background:#16213e;border-left:4px solid #e94560;padding:1rem;margin:0.7rem 0;border-radius:6px'>
                <strong style='color:#e94560;font-size:1.05rem'>{title}</strong><br>
                <span style='color:#ccc'>{body}</span>
            </div>""", unsafe_allow_html=True)

    with tabs[1]:
        st.markdown("### 👥 Consumer Behaviour Findings")
        col1, col2 = st.columns(2)
        insights_a = [
            ("Repeat Purchase Rate is 38%","Well below the 55–60% benchmark for branded fashion. Improving post-purchase service and alteration quality is the #1 retention lever."),
            ("Mall > High Street for Trust","35% prefer mall-based stores for premium ethnic wear. Brand trust, ambience, and alteration services are the top three Mall choice drivers."),
            ("Size Inclusivity Gap","XL/XXL sizes represent 35% of demand but <20% of most competitor SKUs. A size-inclusive range is a direct revenue opportunity."),
        ]
        insights_b = [
            ("Fusion/Indo-Western Rising","22% of consumers prefer Fusion style, driven by 26–35 age group professionals who wear ethnic-adjacent at work."),
            ("WhatsApp Commerce Matters","18% of purchases in this segment are initiated via WhatsApp. A dedicated WhatsApp Business catalogue with pricing is non-negotiable."),
            ("Satisfaction Score 3.8/5","Below 4.0 — consumers are not delighted by current offerings. Quality consistency + after-sale alteration are the top improvement areas."),
        ]
        with col1:
            for t,b in insights_a:
                st.markdown(f"""<div style='background:#0f3460;border-radius:6px;padding:0.9rem;margin:0.4rem 0'>
                    <strong style='color:#f6ad55'>{t}</strong><br><small style='color:#ccc'>{b}</small></div>""",
                    unsafe_allow_html=True)
        with col2:
            for t,b in insights_b:
                st.markdown(f"""<div style='background:#0f3460;border-radius:6px;padding:0.9rem;margin:0.4rem 0'>
                    <strong style='color:#f6ad55'>{t}</strong><br><small style='color:#ccc'>{b}</small></div>""",
                    unsafe_allow_html=True)

    with tabs[2]:
        st.markdown("### 🤖 ML Model Insights")
        st.markdown("""
        #### Model Performance Summary

        All four classifiers (KNN, Decision Tree, Random Forest, Gradient Boosting) were trained on 31 engineered features
        to predict Purchase Intent (Low / Medium / High).

        **Key Results:**

        | Model | Test Accuracy | Best For |
        |---|---|---|
        | KNN | ~62–66% | Baseline, neighbourhood-level patterns |
        | Decision Tree | ~68–72% | Interpretability, rule extraction |
        | Random Forest | ~76–80% | Production use, robust predictions |
        | Gradient Boosting | ~78–83% | Highest accuracy, complex patterns |

        #### Top Predictive Features (from Random Forest & Gradient Boosting):
        1. **Repeat_Flag** — Prior repeat purchase is the single strongest predictor of High Intent
        2. **Is_Festive_Flag** — Festive wear purchases signal 2.4× higher intent
        3. **Log_Spend** — Higher spend tier strongly correlates with intent level
        4. **Festive_Premium** — Interaction of festive season × premium tier
        5. **Is_Peak_Season** — Being in Eid/Diwali/Wedding season adds predictive power
        6. **Income_Price_Ratio** — Consumers spending within their income comfort zone show higher intent
        7. **Conversion_Traffic** — Combined footfall × conversion rate signals high-intent store visits
        8. **Log_Social_Reach** — Digital reach quality correlates with intent
        9. **Is_South_Asian** — Community identity is a meaningful segment predictor
        10. **Price_Num** — Price tier is a consistently informative feature

        #### Diagnostic Findings from ML:
        - **Decision Tree** identifies clear rules: e.g., *Repeat=Yes AND Festive=Yes AND Premium → 89% High Intent*
        - **Gradient Boosting** captures non-linear interactions between season × nationality × channel
        - **Overfitting check:** Decision Tree shows the most overfitting (train >> test). Use Random Forest/GB in production.
        - **ROC-AUC** for Random Forest and Gradient Boosting exceeds 0.88 across all three intent classes, indicating excellent discriminative power.
        """)

    with tabs[3]:
        st.markdown("### 🎯 Strategic Recommendations")
        recs = [
            ("PRIORITY 1", "Target the 26–45 Mid-Premium Segment First",
             "This cohort (58% of total demand) earns AED 10K–40K/month, shops during all 5 peak seasons, and responds to Instagram/WhatsApp marketing. Design your initial 50-SKU range around Kurtas, Sherwanis and Fusion Jackets at AED 450–900."),
            ("PRIORITY 2", "Open First in a Community-Adjacent Location",
             "A high-street store in Karama, Meena Bazaar, or Bur Dubai before expanding to mall. Lower rent allows longer runway. Serve as manufacturing + retail hub simultaneously."),
            ("PRIORITY 3", "Launch a WhatsApp-First Sales Engine",
             "Build a WhatsApp Business catalogue with 40–60 hero SKUs. Offer consultation → measurement → order → delivery via chat. This channel has 18% purchase initiation rate in your target segment."),
            ("PRIORITY 4", "Invest in Custom/Bespoke as Differentiator",
             "Competitors do not offer quick-turnaround bespoke at mid-premium price. 7-day custom at AED 550–850 is a high-margin, high-loyalty product. Own manufacturing makes this viable."),
            ("PRIORITY 5", "Build a Festival Pre-Order Calendar",
             "Launch pre-orders 6 weeks before Eid/Diwali. Offer early-bird 10% discount. This stabilises cash flow, reduces stock risk, and creates marketing moments."),
            ("PRIORITY 6", "Loyalty Programme from Day 1",
             "Simple points system: AED 1 spent = 1 point, 500 points = AED 50 voucher. Repeat purchase rate (currently 38% market average) can be pushed to 55%+ within 18 months with a well-executed programme."),
        ]
        for priority, title, body in recs:
            st.markdown(f"""
            <div style='background:#16213e;border:1px solid #e94560;padding:1.2rem;margin:0.7rem 0;border-radius:8px'>
                <span style='background:#e94560;color:white;padding:2px 10px;border-radius:4px;font-size:0.8rem'>{priority}</span>
                <strong style='color:white;font-size:1rem;margin-left:10px'>{title}</strong><br><br>
                <span style='color:#ccc'>{body}</span>
            </div>""", unsafe_allow_html=True)

    with tabs[4]:
        st.markdown("### 🗓️ Go-to-Market Roadmap")
        phases = {
            "Phase 1 (Months 1–3): Foundation": [
                "Register trade licence (DED) + manufacturing permit",
                "Lease 1,200–1,800 sq ft in Karama / Bur Dubai",
                "Install basic manufacturing setup (5–8 machines)",
                "Develop initial SKU catalogue: 40 Kurtas, 15 Sherwanis, 10 Fusion Jackets",
                "Launch WhatsApp Business + Instagram page",
            ],
            "Phase 2 (Months 4–6): Soft Launch": [
                "Open retail floor (soft launch, invite-only first 2 weeks)",
                "Target Indian and Pakistani community groups on WhatsApp",
                "Run Eid al-Adha pre-order campaign (if in window)",
                "Begin custom/bespoke services",
                "Collect customer data via in-store digital form",
            ],
            "Phase 3 (Months 7–12): Growth": [
                "Launch loyalty programme",
                "Run Instagram Reels campaign with community influencers (micro, 10K–100K)",
                "Add Diwali and Wedding Season pre-order events",
                "Evaluate second location or mall kiosk (pop-up in festival season)",
                "Deploy this ML model to predict and target high-intent consumers",
            ],
            "Phase 4 (Year 2): Scale": [
                "Open Mall-format store (Karama Centre, BurJuman or Ibn Battuta)",
                "Launch e-commerce (website + talabat/noon marketplace listing)",
                "Expand manufacturing capacity to 300–500 units/month",
                "Franchise/wholesale enquiries to Northern Emirates",
            ],
        }
        for phase, steps in phases.items():
            with st.expander(f"📌 {phase}"):
                for step in steps:
                    st.markdown(f"- {step}")

        st.markdown("---")
        st.markdown("""
        <div style='background:linear-gradient(135deg,#1a1a2e,#16213e);border:2px solid #e94560;
                    border-radius:12px;padding:2rem;text-align:center;margin-top:1rem'>
            <h3 style='color:#e94560'>Your Competitive Moat</h3>
            <p style='color:#ccc;font-size:1rem'>
                Own manufacturing + Bespoke speed + Community-embedded sales + Digital-first marketing.<br>
                No current competitor in Dubai's men's ethnic wear market combines all four.<br>
                <strong style='color:white'>This is your unfair advantage.</strong>
            </p>
        </div>
        """, unsafe_allow_html=True)
