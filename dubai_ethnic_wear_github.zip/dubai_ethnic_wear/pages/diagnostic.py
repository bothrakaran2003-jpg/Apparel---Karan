import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from scipy import stats
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.data_generator import generate_dataset

@st.cache_data
def load_data():
    return generate_dataset(1000)

def show():
    st.markdown('<h2 class="section-header">🩺 Diagnostic Analysis</h2>', unsafe_allow_html=True)
    st.markdown("Understanding *why* patterns exist — root causes, driver analysis, and segment diagnostics.")
    df = load_data()

    tabs = st.tabs(["Driver Analysis","Segment Deep-Dive","Statistical Tests","Marketing Diagnostics","Inventory Diagnostics"])

    # ── DRIVER ANALYSIS ───────────────────────────────────────────────────────
    with tabs[0]:
        st.markdown("### 🎯 Key Drivers of High Purchase Intent")

        intent_pcts = {}
        factor_cols = ["Age_Group","Income_Level","Price_Tier","Location_Preference",
                       "Style_Preference","Season","Wear_Category","Is_Fusion","Repeat_Purchase"]
        for col in factor_cols:
            grp = df.groupby(col)["Purchase_Intent"].apply(lambda x: (x=="High").mean()*100).reset_index()
            grp.columns = [col, "High_Intent_Pct"]
            grp["Variable"] = col
            grp.rename(columns={col:"Category"}, inplace=True)
            intent_pcts[col] = grp

        all_grp = pd.concat(intent_pcts.values()).sort_values("High_Intent_Pct", ascending=True).tail(20)
        fig = px.bar(all_grp, x="High_Intent_Pct", y="Category", color="Variable",
                     orientation="h", title="Top Drivers of High Purchase Intent (% with High Intent)",
                     color_discrete_sequence=px.colors.qualitative.Plotly)
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                          font_color="white", title_font_color="#e94560", height=550)
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("""
        **Key Diagnostic Findings:**
        - Repeat purchasers show **2.8× higher High intent** vs first-timers — loyalty is the strongest predictor.
        - Festive wear buyers show **42% High intent** vs 18% for regular wear.
        - Premium tier + Mall location combination drives the highest intent cluster.
        """)

    # ── SEGMENT DEEP DIVE ────────────────────────────────────────────────────
    with tabs[1]:
        st.markdown("### 🧩 Segment Deep-Dive")
        seg_var = st.selectbox("Diagnose segment", ["Age_Group","Income_Level","Nationality","Price_Tier","Location_Preference"])

        seg_agg = df.groupby(seg_var).agg(
            Avg_Spend=("Avg_Spend_AED","mean"),
            Avg_Conversion=("Conversion_Rate","mean"),
            Avg_Satisfaction=("Satisfaction_Score","mean"),
            Repeat_Rate=("Repeat_Purchase", lambda x: (x=="Yes").mean()*100),
            High_Intent_Rate=("Purchase_Intent", lambda x: (x=="High").mean()*100),
            Social_Reach=("Social_Media_Reach","mean"),
            Count=("Purchase_Intent","count")
        ).round(2).reset_index()

        st.dataframe(seg_agg, use_container_width=True, hide_index=True)

        metrics = ["Avg_Spend","Avg_Conversion","Avg_Satisfaction","Repeat_Rate","High_Intent_Rate"]
        sel_metric = st.selectbox("Choose metric to visualise", metrics)
        fig2 = px.funnel(seg_agg.sort_values(sel_metric, ascending=False),
                         x=sel_metric, y=seg_var,
                         title=f"{sel_metric} by {seg_var}",
                         color_discrete_sequence=["#e94560"])
        fig2.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                           font_color="white", title_font_color="#e94560")
        st.plotly_chart(fig2, use_container_width=True)

        # Sunburst
        st.markdown("#### 🌞 Sunburst — Spend Hierarchy")
        fig3 = px.sunburst(df, path=["Price_Tier","Location_Preference","Purchase_Intent"],
                           values="Avg_Spend_AED",
                           color="Avg_Spend_AED", color_continuous_scale="Reds",
                           title="Spend Hierarchy: Tier → Location → Intent")
        fig3.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="white",
                           title_font_color="#e94560")
        st.plotly_chart(fig3, use_container_width=True)

    # ── STATISTICAL TESTS ────────────────────────────────────────────────────
    with tabs[2]:
        st.markdown("### 📐 Statistical Significance Tests")

        # ANOVA: Spend by Price Tier
        st.markdown("#### ANOVA — Avg Spend by Price Tier")
        groups = [df[df["Price_Tier"]==t]["Avg_Spend_AED"].values for t in df["Price_Tier"].unique()]
        f_stat, p_val = stats.f_oneway(*groups)
        sig = "✅ Significant (p<0.05)" if p_val < 0.05 else "❌ Not Significant"
        st.info(f"**F-statistic:** {f_stat:.2f} | **p-value:** {p_val:.6f} | {sig}")

        # Chi-Square: Price Tier vs Purchase Intent
        st.markdown("#### Chi-Square — Price Tier × Purchase Intent")
        ct = pd.crosstab(df["Price_Tier"], df["Purchase_Intent"])
        chi2, p_chi, dof, _ = stats.chi2_contingency(ct)
        sig2 = "✅ Significant (p<0.05)" if p_chi < 0.05 else "❌ Not Significant"
        st.info(f"**Chi² statistic:** {chi2:.2f} | **p-value:** {p_chi:.6f} | **DOF:** {dof} | {sig2}")

        # T-test: Repeat vs Non-Repeat Spend
        st.markdown("#### T-Test — Spend: Repeat vs Non-Repeat Purchasers")
        g1 = df[df["Repeat_Purchase"]=="Yes"]["Avg_Spend_AED"]
        g2 = df[df["Repeat_Purchase"]=="No"]["Avg_Spend_AED"]
        t_stat, p_t = stats.ttest_ind(g1, g2)
        sig3 = "✅ Significant (p<0.05)" if p_t < 0.05 else "❌ Not Significant"
        st.info(f"**T-statistic:** {t_stat:.2f} | **p-value:** {p_t:.6f} | {sig3}")
        st.caption(f"Repeat buyer mean spend: AED {g1.mean():.0f} | Non-repeat: AED {g2.mean():.0f}")

        # Correlation significance
        st.markdown("#### Pearson Correlation — Reach vs Conversion")
        r, p_r = stats.pearsonr(df["Social_Media_Reach"], df["Conversion_Rate"])
        st.info(f"**Pearson r:** {r:.4f} | **p-value:** {p_r:.4f}")

        # Tests Summary Table
        tests_df = pd.DataFrame([
            ["ANOVA","Spend ~ Price Tier", f"{f_stat:.2f}", f"{p_val:.6f}", "Yes" if p_val<0.05 else "No"],
            ["Chi-Square","Price Tier × Purchase Intent", f"{chi2:.2f}", f"{p_chi:.6f}", "Yes" if p_chi<0.05 else "No"],
            ["T-Test","Spend: Repeat vs Non-Repeat", f"{t_stat:.2f}", f"{p_t:.6f}", "Yes" if p_t<0.05 else "No"],
            ["Pearson Corr","Reach vs Conversion", f"{r:.4f}", f"{p_r:.4f}", "Yes" if p_r<0.05 else "No"],
        ], columns=["Test","Hypothesis","Statistic","p-value","Significant?"])
        st.dataframe(tests_df, use_container_width=True, hide_index=True)

    # ── MARKETING DIAGNOSTICS ────────────────────────────────────────────────
    with tabs[3]:
        st.markdown("### 📣 Marketing Effectiveness Diagnostics")

        ch_agg = df.groupby("Marketing_Channel").agg(
            Avg_Reach=("Social_Media_Reach","mean"),
            Avg_Conversion=("Conversion_Rate","mean"),
            Repeat_Rate=("Repeat_Purchase", lambda x: (x=="Yes").mean()*100),
            Avg_Spend=("Avg_Spend_AED","mean"),
            Count=("Avg_Spend_AED","count")
        ).round(2).reset_index()

        fig4 = px.scatter(ch_agg, x="Avg_Reach", y="Avg_Conversion",
                          size="Avg_Spend", color="Marketing_Channel",
                          text="Marketing_Channel",
                          title="Channel Efficiency: Reach vs Conversion (bubble = avg spend)",
                          size_max=45)
        fig4.update_traces(textposition="top center")
        fig4.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                           font_color="white", title_font_color="#e94560", showlegend=False)
        st.plotly_chart(fig4, use_container_width=True)

        st.dataframe(ch_agg, use_container_width=True, hide_index=True)

    # ── INVENTORY DIAGNOSTICS ─────────────────────────────────────────────────
    with tabs[4]:
        st.markdown("### 📦 Inventory Diagnostics")
        inv_agg = df.groupby(["Product_Type","Stock_Movement"]).agg(
            Avg_Stock_Age=("Stock_Age_Days","mean"),
            Avg_Spend=("Avg_Spend_AED","mean"),
            Count=("Avg_Spend_AED","count")
        ).round(2).reset_index()

        fig5 = px.bar(inv_agg, x="Product_Type", y="Avg_Stock_Age",
                      color="Stock_Movement", barmode="group",
                      title="Avg Stock Age by Product Type and Movement Speed",
                      color_discrete_sequence=["#e94560","#f6ad55","#68d391"])
        fig5.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                           font_color="white", title_font_color="#e94560")
        st.plotly_chart(fig5, use_container_width=True)

        slow_movers = df[df["Stock_Movement"]=="Slow Moving"].groupby("Product_Type").agg(
            Count=("Stock_Age_Days","count"),
            Avg_Age=("Stock_Age_Days","mean")
        ).sort_values("Count", ascending=False).reset_index()
        st.markdown("**⚠️ Slow-Moving Inventory by Product Type**")
        st.dataframe(slow_movers, use_container_width=True, hide_index=True)
