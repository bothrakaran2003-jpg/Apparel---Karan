import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.data_generator import generate_dataset

@st.cache_data
def load_data():
    return generate_dataset(1000)

def show():
    st.markdown('<h2 class="section-header">🔍 Descriptive Analysis</h2>', unsafe_allow_html=True)
    df = load_data()

    # ── Summary Stats ─────────────────────────────────────────────────────────
    st.markdown("### 📐 Numerical Summary Statistics")
    num_cols = ["Avg_Spend_AED","Stock_Age_Days","Social_Media_Reach","Instore_Traffic","Conversion_Rate","Satisfaction_Score"]
    st.dataframe(df[num_cols].describe().round(2), use_container_width=True)

    st.markdown("---")
    st.markdown("### 📊 Univariate Distribution Plots")

    cat_tab, num_tab = st.tabs(["Categorical Variables", "Numerical Variables"])

    with cat_tab:
        cat_vars = ["Age_Group","Income_Level","Style_Preference","Product_Type",
                    "Price_Tier","Location_Preference","Season","Purchase_Intent"]
        sel = st.selectbox("Select categorical variable", cat_vars)
        vc = df[sel].value_counts().reset_index()
        vc.columns = [sel, "Count"]
        fig = px.bar(vc, x=sel, y="Count", color="Count",
                     color_continuous_scale="Reds",
                     title=f"Distribution of {sel}")
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                          font_color="white", title_font_color="#e94560")
        st.plotly_chart(fig, use_container_width=True)

    with num_tab:
        sel2 = st.selectbox("Select numerical variable", num_cols)
        fig2 = make_subplots(rows=1, cols=2, subplot_titles=["Histogram","Box Plot"])
        fig2.add_trace(go.Histogram(x=df[sel2], marker_color="#e94560", name="Distribution"), row=1, col=1)
        fig2.add_trace(go.Box(y=df[sel2], marker_color="#e94560", name="Box"), row=1, col=2)
        fig2.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                           font_color="white", showlegend=False,
                           title=dict(text=f"Distribution of {sel2}", font=dict(color="#e94560")))
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("---")
    # ── Cross Tabulation ──────────────────────────────────────────────────────
    st.markdown("### 🔢 Cross-Tabulation Analysis")

    ct_options = {
        "Price Tier × Purchase Intent": ("Price_Tier","Purchase_Intent"),
        "Age Group × Style Preference": ("Age_Group","Style_Preference"),
        "Location × Price Tier": ("Location_Preference","Price_Tier"),
        "Season × Wear Category": ("Season","Wear_Category"),
        "Nationality × Product Type": ("Nationality","Product_Type"),
        "Income Level × Price Tier": ("Income_Level","Price_Tier"),
        "Marketing Channel × Repeat Purchase": ("Marketing_Channel","Repeat_Purchase"),
        "Stock Movement × Reorder Frequency": ("Stock_Movement","Reorder_Frequency"),
    }
    sel_ct = st.selectbox("Select cross-tabulation", list(ct_options.keys()))
    row_var, col_var = ct_options[sel_ct]

    ct = pd.crosstab(df[row_var], df[col_var], margins=True)
    ct_pct = pd.crosstab(df[row_var], df[col_var], normalize="index").mul(100).round(1)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Raw Counts**")
        st.dataframe(ct, use_container_width=True)
    with c2:
        st.markdown("**Row % Distribution**")
        st.dataframe(ct_pct.style.background_gradient(cmap="RdYlGn"), use_container_width=True)

    # Heatmap
    fig3 = px.imshow(ct_pct.iloc[:-1, :], text_auto=True,
                     color_continuous_scale="RdBu_r",
                     title=f"Cross-Tab Heatmap: {row_var} × {col_var} (Row %)")
    fig3.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="white",
                       title_font_color="#e94560")
    st.plotly_chart(fig3, use_container_width=True)

    st.markdown("---")
    # ── Bivariate Analysis ────────────────────────────────────────────────────
    st.markdown("### 🔀 Bivariate Analysis — Spend by Segments")

    col1, col2 = st.columns(2)
    with col1:
        fig4 = px.box(df, x="Price_Tier", y="Avg_Spend_AED",
                      color="Purchase_Intent", color_discrete_sequence=["#e94560","#f6ad55","#68d391"],
                      title="Spend Distribution by Price Tier & Intent")
        fig4.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                           font_color="white", title_font_color="#e94560")
        st.plotly_chart(fig4, use_container_width=True)

    with col2:
        spend_season = df.groupby("Season")["Avg_Spend_AED"].mean().reset_index().sort_values("Avg_Spend_AED", ascending=False)
        fig5 = px.bar(spend_season, x="Season", y="Avg_Spend_AED",
                      color="Avg_Spend_AED", color_continuous_scale="Reds",
                      title="Avg Spend by Season")
        fig5.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                           font_color="white", title_font_color="#e94560")
        st.plotly_chart(fig5, use_container_width=True)

    # ── Correlation Matrix ────────────────────────────────────────────────────
    st.markdown("### 🔗 Correlation Matrix — Numerical Features")
    corr = df[num_cols].corr().round(2)
    fig6 = px.imshow(corr, text_auto=True, color_continuous_scale="RdBu_r",
                     title="Pearson Correlation Matrix")
    fig6.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="white",
                       title_font_color="#e94560")
    st.plotly_chart(fig6, use_container_width=True)

    # ── Multi-dim breakdown ───────────────────────────────────────────────────
    st.markdown("### 🌐 Multi-Dimensional: Spend × Reach × Conversion by Segment")
    fig7 = px.scatter(df.sample(400, random_state=1),
                      x="Social_Media_Reach", y="Avg_Spend_AED",
                      color="Price_Tier", size="Conversion_Rate",
                      facet_col="Purchase_Intent",
                      color_discrete_sequence=["#e94560","#f6ad55","#68d391"],
                      title="Social Reach vs Spend by Price Tier (bubble = conversion rate)")
    fig7.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                       font_color="white", title_font_color="#e94560")
    st.plotly_chart(fig7, use_container_width=True)
