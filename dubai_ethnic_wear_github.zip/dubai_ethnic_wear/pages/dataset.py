import streamlit as st
import pandas as pd
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.data_generator import generate_dataset

@st.cache_data
def load_data():
    return generate_dataset(1000)

def show():
    st.markdown('<h2 class="section-header">📊 Synthetic Consumer Dataset</h2>', unsafe_allow_html=True)
    st.markdown("""
    Synthetic dataset of **1,000 consumer records** simulating the Dubai Men's Ethnic Wear market.
    Generated using realistic probability distributions based on market research assumptions.
    """)

    df = load_data()

    # Controls
    c1,c2,c3 = st.columns(3)
    with c1:
        n_show = st.slider("Rows to preview", 10, 100, 25)
    with c2:
        price_filter = st.multiselect("Filter by Price Tier", df["Price_Tier"].unique(), df["Price_Tier"].unique())
    with c3:
        intent_filter = st.multiselect("Filter by Purchase Intent", df["Purchase_Intent"].unique(), df["Purchase_Intent"].unique())

    filtered = df[df["Price_Tier"].isin(price_filter) & df["Purchase_Intent"].isin(intent_filter)]
    st.dataframe(filtered.head(n_show), use_container_width=True, hide_index=True)

    st.markdown(f"**Total Records:** {len(filtered)} | **Columns:** {df.shape[1]}")

    # Column guide
    with st.expander("📖 Column Dictionary"):
        col_dict = {
            "Age_Group":"Consumer age bracket (18-25 to 56+)",
            "Income_Level":"Monthly income in AED",
            "Nationality":"Ethnic background of consumer",
            "Style_Preference":"Preferred clothing aesthetic",
            "Size_Range":"Garment size (S to Custom)",
            "Product_Type":"Type of ethnic garment",
            "Wear_Category":"Festive or Regular wear occasion",
            "Is_Fusion":"Whether product is a fusion/Indo-western style",
            "Location_Preference":"Preferred purchase channel/location",
            "Price_Tier":"Pricing segment (Affordable / Mid-Premium / Premium)",
            "Avg_Spend_AED":"Average transaction value in AED",
            "Stock_Movement":"Inventory velocity (Fast/Moderate/Slow)",
            "Stock_Age_Days":"Days since item entered inventory",
            "Reorder_Frequency":"How often stock is replenished",
            "Social_Media_Reach":"Estimated organic social media reach",
            "Instore_Traffic":"Footfall count per week",
            "Conversion_Rate":"% of visitors making a purchase",
            "Repeat_Purchase":"Whether consumer bought again (Yes/No)",
            "Marketing_Channel":"Primary acquisition source",
            "Season":"Current demand season/festival",
            "Satisfaction_Score":"Post-purchase rating (1–5)",
            "Purchase_Intent":"Target variable — High / Medium / Low intent",
        }
        st.table(pd.DataFrame(col_dict.items(), columns=["Column","Description"]))

    # Download
    csv = df.to_csv(index=False).encode()
    st.download_button("⬇️ Download Full Dataset (CSV)", csv, "dubai_ethnic_wear_data.csv", "text/csv")
