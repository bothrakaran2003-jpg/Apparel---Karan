import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (classification_report, confusion_matrix,
                              roc_curve, auc, accuracy_score,
                              precision_recall_fscore_support)
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.data_generator import generate_dataset
from pages.ml_models import feature_engineer

@st.cache_data
def load_data():
    return generate_dataset(1000)

@st.cache_data
def train_all_models(test_size=0.25, rand_state=42):
    df = load_data()
    X, y, feature_cols = feature_engineer(df)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=test_size,
                                                random_state=rand_state, stratify=y)
    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_tr)
    X_te_s  = scaler.transform(X_te)

    models = {
        "KNN":              KNeighborsClassifier(n_neighbors=7, metric="euclidean"),
        "Decision Tree":    DecisionTreeClassifier(max_depth=8, min_samples_split=15, random_state=rand_state),
        "Random Forest":    RandomForestClassifier(n_estimators=150, max_depth=10,
                                                    min_samples_split=10, random_state=rand_state, n_jobs=-1),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=150, learning_rate=0.08,
                                                         max_depth=5, random_state=rand_state),
    }

    results = {}
    for name, model in models.items():
        model.fit(X_tr_s, y_tr)
        y_pred = model.predict(X_te_s)
        y_prob = model.predict_proba(X_te_s) if hasattr(model, "predict_proba") else None
        train_acc = model.score(X_tr_s, y_tr)
        test_acc  = model.score(X_te_s, y_te)
        cv_scores = cross_val_score(model, X_tr_s, y_tr, cv=5, scoring="accuracy")
        p, r, f1, _ = precision_recall_fscore_support(y_te, y_pred, average="weighted")
        cm = confusion_matrix(y_te, y_pred)
        report = classification_report(y_te, y_pred,
                                        target_names=["Low","Medium","High"], output_dict=True)
        results[name] = {
            "model": model, "y_pred": y_pred, "y_prob": y_prob,
            "train_acc": train_acc, "test_acc": test_acc,
            "cv_mean": cv_scores.mean(), "cv_std": cv_scores.std(),
            "precision": p, "recall": r, "f1": f1,
            "confusion_matrix": cm, "report": report
        }

    y_bin = label_binarize(y_te, classes=[0,1,2])
    return results, X_tr_s, X_te_s, y_tr, y_te, y_bin, feature_cols

def show():
    st.markdown('<h2 class="section-header">📈 Model Performance Dashboard</h2>', unsafe_allow_html=True)

    with st.spinner("🔄 Training 4 classifiers... please wait"):
        results, X_tr_s, X_te_s, y_tr, y_te, y_bin, feature_cols = train_all_models()

    colors = {"KNN":"#e94560","Decision Tree":"#f6ad55","Random Forest":"#68d391","Gradient Boosting":"#63b3ed"}

    # ── Accuracy Summary ──────────────────────────────────────────────────────
    st.markdown("### 🏆 Model Accuracy Summary")
    col_kpis = st.columns(4)
    for (name, res), col in zip(results.items(), col_kpis):
        col.markdown(f"""
        <div class="metric-card">
            <h3>{res['test_acc']*100:.1f}%</h3>
            <p>{name}<br><small>Train: {res['train_acc']*100:.1f}% | CV: {res['cv_mean']*100:.1f}%±{res['cv_std']*100:.1f}%</small></p>
        </div>
        """, unsafe_allow_html=True)

    # ── Train vs Test Accuracy Bar ────────────────────────────────────────────
    st.markdown("### 📊 Train vs Test Accuracy Comparison")
    acc_df = pd.DataFrame({
        "Model": list(results.keys()),
        "Train Accuracy": [r["train_acc"]*100 for r in results.values()],
        "Test Accuracy":  [r["test_acc"]*100 for r in results.values()],
        "CV Accuracy":    [r["cv_mean"]*100 for r in results.values()],
    })
    acc_melt = acc_df.melt("Model", var_name="Split", value_name="Accuracy (%)")
    fig1 = px.bar(acc_melt, x="Model", y="Accuracy (%)", color="Split", barmode="group",
                  color_discrete_sequence=["#e94560","#68d391","#63b3ed"],
                  title="Train / Test / CV Accuracy by Model")
    fig1.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                       font_color="white", title_font_color="#e94560")
    st.plotly_chart(fig1, use_container_width=True)

    # ── Precision Recall F1 ───────────────────────────────────────────────────
    st.markdown("### 🎯 Precision · Recall · F1 Score")
    prf_df = pd.DataFrame({
        "Model":     list(results.keys()),
        "Precision": [r["precision"]*100 for r in results.values()],
        "Recall":    [r["recall"]*100 for r in results.values()],
        "F1 Score":  [r["f1"]*100 for r in results.values()],
    })
    prf_melt = prf_df.melt("Model", var_name="Metric", value_name="Score (%)")
    fig2 = px.bar(prf_melt, x="Model", y="Score (%)", color="Metric", barmode="group",
                  color_discrete_sequence=["#e94560","#f6ad55","#68d391"],
                  title="Weighted Precision · Recall · F1 by Model")
    fig2.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                       font_color="white", title_font_color="#e94560")
    st.plotly_chart(fig2, use_container_width=True)

    # ── Radar Chart ───────────────────────────────────────────────────────────
    st.markdown("### 🕸️ Radar Comparison of All Metrics")
    cats = ["Train Acc","Test Acc","CV Acc","Precision","Recall","F1"]
    fig3 = go.Figure()
    for name, res in results.items():
        vals = [res["train_acc"]*100, res["test_acc"]*100, res["cv_mean"]*100,
                res["precision"]*100, res["recall"]*100, res["f1"]*100]
        fig3.add_trace(go.Scatterpolar(r=vals+[vals[0]], theta=cats+[cats[0]],
                                        fill="toself", name=name,
                                        line_color=colors[name], opacity=0.7))
    fig3.update_layout(polar=dict(radialaxis=dict(range=[50,100])),
                       paper_bgcolor="rgba(0,0,0,0)", font_color="white",
                       title=dict(text="Model Comparison Radar", font=dict(color="#e94560")))
    st.plotly_chart(fig3, use_container_width=True)

    # ── Confusion Matrices ────────────────────────────────────────────────────
    st.markdown("### 🔲 Confusion Matrices (All Models)")
    labels = ["Low","Medium","High"]
    cm_cols = st.columns(2)
    for i, (name, res) in enumerate(results.items()):
        cm = res["confusion_matrix"]
        fig_cm = px.imshow(cm, text_auto=True, x=labels, y=labels,
                           color_continuous_scale="Reds",
                           title=f"Confusion Matrix — {name}",
                           labels=dict(x="Predicted", y="Actual"))
        fig_cm.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="white",
                              title_font_color=colors[name])
        cm_cols[i % 2].plotly_chart(fig_cm, use_container_width=True)

    # ── ROC Curves ────────────────────────────────────────────────────────────
    st.markdown("### 📉 ROC Curves (One-vs-Rest, All Classes)")
    class_labels = ["Low (0)","Medium (1)","High (2)"]

    roc_tabs = st.tabs(list(results.keys()))
    for tab, (name, res) in zip(roc_tabs, results.items()):
        with tab:
            if res["y_prob"] is not None:
                fig_roc = go.Figure()
                roc_colors = ["#e94560","#f6ad55","#68d391"]
                for cls_i in range(3):
                    fpr, tpr, _ = roc_curve(y_bin[:, cls_i], res["y_prob"][:, cls_i])
                    roc_auc = auc(fpr, tpr)
                    fig_roc.add_trace(go.Scatter(x=fpr, y=tpr, mode="lines",
                                                  name=f"{class_labels[cls_i]} AUC={roc_auc:.3f}",
                                                  line=dict(color=roc_colors[cls_i], width=2)))
                fig_roc.add_trace(go.Scatter(x=[0,1], y=[0,1], mode="lines",
                                              line=dict(color="gray", dash="dash"), name="Random"))
                fig_roc.update_layout(
                    title=f"ROC Curve — {name}",
                    xaxis_title="False Positive Rate", yaxis_title="True Positive Rate",
                    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                    font_color="white", title_font_color=colors[name])
                st.plotly_chart(fig_roc, use_container_width=True)

                # Per-class report
                rep = res["report"]
                rep_df = pd.DataFrame({k:v for k,v in rep.items()
                                        if k in ["Low","Medium","High"]}).T[["precision","recall","f1-score","support"]]
                rep_df = rep_df.round(3)
                st.dataframe(rep_df, use_container_width=True)

    # ── Feature Importance ────────────────────────────────────────────────────
    st.markdown("### 🔑 Feature Importance — Random Forest & Gradient Boosting")
    fi_tabs = st.tabs(["Random Forest","Gradient Boosting"])
    for tab, model_name in zip(fi_tabs, ["Random Forest","Gradient Boosting"]):
        with tab:
            model = results[model_name]["model"]
            fi = pd.DataFrame({"Feature": feature_cols,
                                "Importance": model.feature_importances_*100})
            fi = fi.sort_values("Importance", ascending=True).tail(20)
            fig_fi = px.bar(fi, x="Importance", y="Feature", orientation="h",
                            title=f"Top 20 Feature Importances — {model_name}",
                            color="Importance", color_continuous_scale="Reds")
            fig_fi.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,10,30,0.5)",
                                  font_color="white", title_font_color="#e94560")
            st.plotly_chart(fig_fi, use_container_width=True)

    # ── Full Comparison Table ─────────────────────────────────────────────────
    st.markdown("### 📋 Full Performance Comparison Table")
    final_df = pd.DataFrame({
        "Model":     list(results.keys()),
        "Train Acc %": [f"{r['train_acc']*100:.2f}" for r in results.values()],
        "Test Acc %":  [f"{r['test_acc']*100:.2f}"  for r in results.values()],
        "CV Acc %":    [f"{r['cv_mean']*100:.2f}±{r['cv_std']*100:.2f}" for r in results.values()],
        "Precision %": [f"{r['precision']*100:.2f}" for r in results.values()],
        "Recall %":    [f"{r['recall']*100:.2f}"    for r in results.values()],
        "F1 Score %":  [f"{r['f1']*100:.2f}"        for r in results.values()],
        "Overfitting?": ["Yes" if (r["train_acc"]-r["test_acc"])>0.08 else "No" for r in results.values()]
    })
    st.dataframe(final_df, use_container_width=True, hide_index=True)
