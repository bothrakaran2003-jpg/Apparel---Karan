import streamlit as st
import pandas as pd

def show():
    st.markdown('<h2 class="section-header">📋 Consumer Survey Questionnaire</h2>', unsafe_allow_html=True)
    st.markdown("""
    Structured survey instrument for primary data collection from consumers of Men's Ethnic Wear in Dubai.
    Covers 7 sections with 42 questions across demographics, behaviour, product, channel, marketing, and satisfaction.
    """)

    tabs = st.tabs([
        "Section A: Demographics","Section B: Purchase Behaviour","Section C: Product Preferences",
        "Section D: Channel & Location","Section E: Pricing","Section F: Marketing","Section G: Satisfaction"
    ])

    # ── A: Demographics ───────────────────────────────────────────────────────
    with tabs[0]:
        st.markdown("### Section A — Respondent Demographics")
        st.markdown("*These questions help us understand who our customers are.*")
        questions = [
            ("A1","Age Group","Single Choice",
             "○ 18–25  ○ 26–35  ○ 36–45  ○ 46–55  ○ 56 and above"),
            ("A2","Nationality / Ethnic Background","Single Choice",
             "○ Indian  ○ Pakistani  ○ Bangladeshi  ○ Sri Lankan  ○ Emirati  ○ Other Arab  ○ Other"),
            ("A3","Monthly Household Income (AED)","Single Choice",
             "○ Below 5,000  ○ 5,000–10,000  ○ 10,001–20,000  ○ 20,001–40,000  ○ Above 40,000  ○ Prefer not to say"),
            ("A4","Occupation","Single Choice",
             "○ Salaried Professional  ○ Business Owner  ○ Student  ○ Self-employed  ○ Retired  ○ Other"),
            ("A5","Years Residing in Dubai","Single Choice",
             "○ Less than 1 year  ○ 1–3 years  ○ 3–7 years  ○ 7–15 years  ○ 15+ years"),
            ("A6","Marital Status","Single Choice",
             "○ Single  ○ Married  ○ Married with children  ○ Other"),
        ]
        _render_questions(questions)

    # ── B: Purchase Behaviour ─────────────────────────────────────────────────
    with tabs[1]:
        st.markdown("### Section B — Purchase Behaviour")
        questions = [
            ("B1","How often do you purchase Men's ethnic wear?","Single Choice",
             "○ Weekly  ○ Monthly  ○ Every 3 months  ○ Only for festivals/events  ○ Once a year or less"),
            ("B2","What occasions drive your ethnic wear purchase?","Multiple Choice",
             "☐ Eid al-Fitr  ☐ Eid al-Adha  ☐ Diwali  ☐ Wedding (guest)  ☐ Wedding (groom)  ☐ National Day  ☐ Family gathering  ☐ Casual daily wear"),
            ("B3","How much do you typically spend per ethnic wear purchase?","Single Choice",
             "○ Below AED 150  ○ AED 150–350  ○ AED 350–700  ○ AED 700–1,500  ○ Above AED 1,500"),
            ("B4","How far in advance do you plan a festive clothing purchase?","Single Choice",
             "○ Day before  ○ 1 week before  ○ 2–4 weeks before  ○ 1–2 months before  ○ No advance planning"),
            ("B5","Have you purchased from the same ethnic wear brand more than once?","Single Choice",
             "○ Yes, regularly  ○ Yes, occasionally  ○ No, I switch brands  ○ Not sure"),
            ("B6","What is the primary reason you switched brands or tried a new brand?","Single Choice",
             "○ Price  ○ Quality  ○ Style variety  ○ Recommendation  ○ Convenience  ○ Promotional offer"),
            ("B7","Do you plan your ethnic wear purchases around UAE cultural/national events?","Single Choice",
             "○ Always  ○ Often  ○ Sometimes  ○ Rarely  ○ Never"),
        ]
        _render_questions(questions)

    # ── C: Product Preferences ────────────────────────────────────────────────
    with tabs[2]:
        st.markdown("### Section C — Product Preferences")
        questions = [
            ("C1","Which types of Men's ethnic wear do you prefer?","Multiple Choice",
             "☐ Kurta (plain/printed)  ☐ Sherwani  ☐ Pathani Suit  ☐ Achkan  ☐ Dhoti Kurta  ☐ Indo-Western Blazer  ☐ Fusion Jacket"),
            ("C2","What style best describes your preference?","Single Choice",
             "○ Traditional  ○ Fusion / Indo-Western  ○ Contemporary  ○ Festive Embellished  ○ Casual Ethnic"),
            ("C3","How important is fabric quality in your purchase decision?","Scale 1–5",
             "1 = Not important → 5 = Extremely important"),
            ("C4","Do you prefer ready-to-wear or custom/bespoke tailoring?","Single Choice",
             "○ Only ready-to-wear  ○ Prefer ready-to-wear but open to custom  ○ Prefer custom  ○ Only custom"),
            ("C5","How important is having a range of sizes (including XL/XXL/Custom)?","Scale 1–5",
             "1 = Not important → 5 = Extremely important"),
            ("C6","Do you prefer ethnic wear that can double as corporate-appropriate attire?","Single Choice",
             "○ Strongly yes  ○ Yes  ○ Neutral  ○ No  ○ Strongly no"),
            ("C7","Which fabric types do you prefer?","Multiple Choice",
             "☐ Cotton  ☐ Linen  ☐ Silk  ☐ Polyester blend  ☐ Georgette  ☐ Khadi  ☐ Velvet (festive)"),
        ]
        _render_questions(questions)

    # ── D: Channel & Location ─────────────────────────────────────────────────
    with tabs[3]:
        st.markdown("### Section D — Channel & Location Preference")
        questions = [
            ("D1","Where do you most often buy ethnic wear in Dubai?","Single Choice",
             "○ Shopping Mall store  ○ High Street / Standalone store  ○ Neighbourhood/community retail  ○ Online (website/app)  ○ Pop-up / Exhibition  ○ WhatsApp group/social order"),
            ("D2","What matters most when choosing a store location?","Rank Top 3",
             "Accessibility | Parking | Community proximity | Brand trust | Ambience | Alteration services"),
            ("D3","How often do you browse online before buying in-store?","Single Choice",
             "○ Always  ○ Often  ○ Sometimes  ○ Rarely  ○ Never"),
            ("D4","How likely are you to purchase ethnic wear online?","Scale 1–5",
             "1 = Very unlikely → 5 = Very likely"),
            ("D5","What is your biggest concern with buying ethnic wear online?","Single Choice",
             "○ Fit/sizing  ○ Fabric quality  ○ Return policy  ○ Colour accuracy  ○ Delivery time  ○ No concern"),
            ("D6","Do you visit Dubai Malls specifically for ethnic wear shopping?","Single Choice",
             "○ Yes, frequently  ○ Yes, during festivals  ○ Occasionally  ○ Never"),
        ]
        _render_questions(questions)

    # ── E: Pricing ────────────────────────────────────────────────────────────
    with tabs[4]:
        st.markdown("### Section E — Pricing & Value Perception")
        questions = [
            ("E1","Which price segment do you associate with quality ethnic wear?","Single Choice",
             "○ Below AED 200 (Budget)  ○ AED 200–500 (Affordable)  ○ AED 500–1,000 (Mid-Premium)  ○ AED 1,000–2,500 (Premium)  ○ Above AED 2,500 (Luxury)"),
            ("E2","Would you pay more for sustainable/handloom ethnic wear?","Single Choice",
             "○ Yes, definitely  ○ Yes, if difference ≤20%  ○ Neutral  ○ Probably not  ○ No"),
            ("E3","Do sales/discounts influence your ethnic wear purchase decision?","Scale 1–5",
             "1 = No influence → 5 = Major influence"),
            ("E4","How important is value-for-money in your purchase decision?","Scale 1–5",
             "1 = Not important → 5 = Extremely important"),
            ("E5","Are you willing to pay a premium for made-in-UAE / locally manufactured ethnic wear?","Single Choice",
             "○ Yes  ○ Depends on price difference  ○ No  ○ Never considered this"),
            ("E6","What pricing model do you prefer for custom orders?","Single Choice",
             "○ Fixed package price  ○ Itemised (fabric + stitching)  ○ Per-occasion bundles  ○ Subscription (annual)  ○ No preference"),
        ]
        _render_questions(questions)

    # ── F: Marketing ─────────────────────────────────────────────────────────
    with tabs[5]:
        st.markdown("### Section F — Marketing & Discovery")
        questions = [
            ("F1","How did you first discover your preferred ethnic wear brand?","Single Choice",
             "○ Instagram  ○ TikTok  ○ WhatsApp recommendation  ○ Walk-in / window display  ○ Friend/family referral  ○ Google search  ○ Event/exhibition"),
            ("F2","Which social media platforms most influence your ethnic wear buying?","Multiple Choice",
             "☐ Instagram  ☐ TikTok  ☐ YouTube  ☐ Facebook  ☐ Pinterest  ☐ Snapchat  ☐ None"),
            ("F3","Do influencer recommendations affect your purchase decisions?","Scale 1–5",
             "1 = Not at all → 5 = Strongly"),
            ("F4","Have you ever purchased ethnic wear based on a social media ad?","Single Choice",
             "○ Yes, multiple times  ○ Yes, once  ○ No, but I clicked to browse  ○ No, never"),
            ("F5","What type of content would make you buy ethnic wear?","Multiple Choice",
             "☐ Lookbooks/style guides  ☐ Behind-the-scenes craftsmanship  ☐ Celebrity wearing it  ☐ Customer try-on videos  ☐ Festival styling tips  ☐ Price/offer announcements"),
            ("F6","Would you participate in a loyalty / points programme for ethnic wear?","Single Choice",
             "○ Definitely  ○ Likely  ○ Neutral  ○ Unlikely  ○ No"),
            ("F7","How important is WhatsApp order & consultation for ethnic wear to you?","Scale 1–5",
             "1 = Not important → 5 = Very important"),
        ]
        _render_questions(questions)

    # ── G: Satisfaction ───────────────────────────────────────────────────────
    with tabs[6]:
        st.markdown("### Section G — Satisfaction & Loyalty")
        questions = [
            ("G1","Overall, how satisfied are you with currently available ethnic wear in Dubai?","Scale 1–5",
             "1 = Very dissatisfied → 5 = Very satisfied"),
            ("G2","What is the biggest gap in the current Dubai ethnic wear market?","Multiple Choice",
             "☐ Size inclusivity  ☐ Fusion styles  ☐ Affordable premium quality  ☐ Quick alteration services  ☐ Omnichannel convenience  ☐ Variety of non-Indian styles  ☐ Sustainable options"),
            ("G3","Would you recommend your favourite ethnic wear brand to friends/family?","Scale 1–10",
             "Net Promoter Score (NPS) scale: 0 = Not at all → 10 = Definitely"),
            ("G4","Have you had a negative experience with ethnic wear in Dubai?","Single Choice",
             "○ Yes, sizing issues  ○ Yes, quality did not match price  ○ Yes, late delivery  ○ Yes, poor after-sales  ○ No negative experience"),
            ("G5","What would make you a loyal customer of a new ethnic wear brand?","Multiple Choice",
             "☐ Consistent quality  ☐ Good alteration service  ☐ Loyalty rewards  ☐ Personalised styling  ☐ Festive previews  ☐ WhatsApp/chat support  ☐ Easy online returns"),
            ("G6","On a scale of 1–10, how likely are you to try a new Dubai-based ethnic wear manufacturer?","Scale 1–10",
             "1 = Very unlikely → 10 = Very likely"),
        ]
        _render_questions(questions)

    # Download as PDF placeholder
    st.markdown("---")
    questionnaire_text = _generate_plain_text_survey()
    st.download_button("⬇️ Download Survey (TXT)", questionnaire_text, 
                       "dubai_ethnic_wear_survey.txt", "text/plain")

def _render_questions(questions):
    for q_id, q_text, q_type, options in questions:
        st.markdown(f"""
        <div style='background:#16213e;border-left:3px solid #e94560;padding:1rem;margin:0.6rem 0;border-radius:6px'>
            <strong style='color:#e94560'>{q_id}.</strong>
            <span style='color:white'> {q_text}</span>
            <span style='background:#0f3460;color:#a0aec0;font-size:0.75rem;padding:2px 8px;border-radius:4px;margin-left:8px'>{q_type}</span><br>
            <span style='color:#a0aec0;font-size:0.85rem'>{options}</span>
        </div>
        """, unsafe_allow_html=True)

def _generate_plain_text_survey():
    return """DUBAI MEN'S ETHNIC WEAR — CONSUMER SURVEY
==========================================
For research purposes only. Takes ~8 minutes to complete.

SECTION A: DEMOGRAPHICS
A1. Age Group: 18-25 / 26-35 / 36-45 / 46-55 / 56+
A2. Nationality/Ethnic Background: Indian/Pakistani/Bangladeshi/Sri Lankan/Emirati/Other Arab/Other
A3. Monthly Household Income (AED): <5K / 5-10K / 10-20K / 20-40K / >40K / Prefer not to say
A4. Occupation: Salaried/Business Owner/Student/Self-employed/Retired/Other
A5. Years in Dubai: <1 / 1-3 / 3-7 / 7-15 / 15+
A6. Marital Status: Single/Married/Married with children/Other

SECTION B: PURCHASE BEHAVIOUR
B1. How often do you buy ethnic wear? Weekly/Monthly/Quarterly/Festivals only/Once a year
B2. Occasions driving purchase (multi-select): Eid/Diwali/Wedding-Guest/Wedding-Groom/National Day/Family/Daily
B3. Typical spend per purchase: <150/150-350/350-700/700-1500/>1500 AED
B4. Advance planning time: Day before/1 week/2-4 weeks/1-2 months/No planning
B5. Repeated same brand? Yes-regularly/Yes-occasionally/No/Not sure
B6. Primary reason to switch brand: Price/Quality/Style variety/Recommendation/Convenience/Offer
B7. Purchase planned around UAE events? Always/Often/Sometimes/Rarely/Never

SECTION C: PRODUCT PREFERENCES
C1. Preferred types (multi): Kurta/Sherwani/Pathani/Achkan/Dhoti Kurta/Indo-Western/Fusion Jacket
C2. Style preference: Traditional/Fusion/Contemporary/Festive/Casual Ethnic
C3. Fabric quality importance: 1-5 scale
C4. Ready-to-wear vs Custom: Only RTW/Prefer RTW/Prefer Custom/Only Custom
C5. Size range importance: 1-5 scale
C6. Ethnic wear as corporate wear: Strongly Yes/Yes/Neutral/No/Strongly No
C7. Preferred fabric (multi): Cotton/Linen/Silk/Polyester blend/Georgette/Khadi/Velvet

SECTION D: CHANNEL & LOCATION
D1. Where do you buy? Mall/High Street/Neighbourhood/Online/Pop-up/WhatsApp
D2. Location priorities (rank 3): Accessibility/Parking/Community/Brand trust/Ambience/Alteration
D3. Online browsing before in-store? Always/Often/Sometimes/Rarely/Never
D4. Likelihood to buy online: 1-5 scale
D5. Biggest online concern: Fit/Quality/Returns/Colour/Delivery/No concern
D6. Visit mall for ethnic wear? Frequently/During festivals/Occasionally/Never

SECTION E: PRICING
E1. Price associated with quality: Budget(<200)/Affordable(200-500)/Mid(500-1000)/Premium(1000-2500)/Luxury(>2500)
E2. Pay extra for sustainable? Definitely/Yes if ≤20% more/Neutral/Probably not/No
E3. Sales/discounts influence: 1-5 scale
E4. Value-for-money importance: 1-5 scale
E5. Pay premium for UAE-made? Yes/Depends/No/Never considered
E6. Custom pricing model: Fixed/Itemised/Bundles/Subscription/No preference

SECTION F: MARKETING
F1. Brand discovery: Instagram/TikTok/WhatsApp/Walk-in/Referral/Google/Event
F2. Social media influence (multi): Instagram/TikTok/YouTube/Facebook/Pinterest/Snapchat/None
F3. Influencer impact: 1-5 scale
F4. Bought via social ad? Yes-many/Yes-once/No-browsed/No-never
F5. Content that drives purchase (multi): Lookbooks/BTS/Celebrity/Try-on/Festival tips/Offers
F6. Loyalty programme interest: Definitely/Likely/Neutral/Unlikely/No
F7. WhatsApp consultation importance: 1-5 scale

SECTION G: SATISFACTION
G1. Overall satisfaction with Dubai ethnic wear market: 1-5 scale
G2. Biggest market gaps (multi): Size/Fusion/Affordable quality/Alteration/Omnichannel/Non-Indian/Sustainable
G3. NPS - Recommend brand: 0-10 scale
G4. Negative experience: Sizing/Quality-price mismatch/Late delivery/Poor after-sales/No
G5. Loyalty drivers (multi): Quality/Alteration/Rewards/Personalised styling/Festive previews/Chat support/Returns
G6. Likelihood to try new Dubai-based brand: 1-10 scale

END OF SURVEY — Thank you for your time.
"""
